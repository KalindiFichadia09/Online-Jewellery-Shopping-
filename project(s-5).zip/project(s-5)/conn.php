<?php

	$con=mysqli_connect('localhost','root','','jayshree_db');
	
	if($con)
	{
		//echo "doneeeeeeeee.............";
	}
	else
	{
		echo "not connected !!!!!!";
	}
?>